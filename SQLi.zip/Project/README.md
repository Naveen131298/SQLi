###  SQL injection Vulnerability Scanner  
**Features**  
1. multiple domain scanning with SQL injection dork with Google.
2. targetted scanning by providing specific domain (with crawling)
3. reverse domain scanning

> both SQLi scanning and domain info checking are done in multiprocessing  
> so the script is super fast at scanning many urls

#libraries
 
> - [bs4](https://pypi.python.org/pypi/bs4)  
> - [termcolor](https://pypi.python.org/pypi/termcolor)  
> - [google](https://pypi.python.org/pypi/google)
> - [nyawc](https://pypi.python.org/pypi/nyawc/)
> - [terminaltables](https://pypi.python.org/pypi/terminaltables)

---
### Quick Info 
**1. Multiple domain scanning with SQLi dork**  
- it simply search multiple websites from given dork and scan the results one by one
```python
python sqli.py -d <SQLI DORK> -e <SEARCH ENGINE>  
python sqli.py -d "inurl:index.php?id=" -e google  
```

**2. Targetted scanning**  
- can provide only domain name or specifc url with query params
- if only domain name is provided, it will crawl and get urls with query
- then scan the urls one by one
```python
python sqli.py -t <URL>  
python sqli.py -t www.example.com  
python sqli.py -t www.example.com/index.php?id=1  
```

**3. Reverse domain and scanning**  
- do reverse domain and look for websites that hosted on same server as target url
```python
python sqli.py -t <URL> -r
```

**4. Dumping scanned result**
- you can dump the scanned results as json by giving this argument
```python
python sqli.py -d <SQLI DORK> -e <SEARCH ENGINE> -o result.json
```

**View help**  
```python
python sqli.py --help

usage: sqli.py [-h] [-d D] [-e E] [-p P] [-t T] [-r]

optional arguments:
  -h, --help  show this help message and exit
  -d D        SQL injection dork
  -e E        search engine [Google]
  -p P        number of websites to look for in search engine
  -t T        scan target website
  -r          reverse domain
```

                  <------------*****End****--------------->
